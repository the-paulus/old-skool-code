Public Class Appointment
    Inherits ImportantDate
    Private nContact As String
    Private nLocation As String
    Private nDuration As TimeSpan
    Private nNotes As String

    Public Sub New(ByVal dt As DateTime, ByVal rs As String, ByVal Contact As String, ByVal Location As String, ByVal Duration As TimeSpan, ByVal Notes As String)
        MyBase.new(dt, rs, False)
        nContact = Contact
        nLocation = Location
        nDuration = Duration
        nNotes = Notes

    End Sub
    Public Property Contact() As String
        Get
            Return nContact
        End Get
        Set(ByVal Value As String)
            nContact = Value

            If nContact = "" Then
                Throw New ArgumentNullException("You must have a contact to make an appointment")
            End If

        End Set
    End Property
    Public Property Location() As String
        Get
            Return nLocation
        End Get
        Set(ByVal Value As String)
            nLocation = Value
            If nLocation = "" Then
                Throw New ArgumentNullException("You must enter in a location for the appointment")
            End If

        End Set
    End Property
    Public Property Notes() As String
        Get
            Return nNotes
        End Get
        Set(ByVal Value As String)
            nNotes = Value
        End Set
    End Property
    Public Property Duration() As TimeSpan
        Get
            Return nDuration
        End Get
        Set(ByVal Value As TimeSpan)
            nDuration = Value
        End Set
    End Property
End Class
