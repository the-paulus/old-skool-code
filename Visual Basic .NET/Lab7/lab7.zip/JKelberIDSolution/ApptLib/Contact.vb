Imports System
<Serializable()> _
Public Class Contact
    Implements IComparable
    Private mLName As String
    Private mFName As String
    Private mEmail As String
    Private mAddress As String
    Private mCity As String
    Private mState As String
    Private mZip As String
    Private mHomePh As String
    Private mWorkPh As String
    Private mCellPh As String
    Private mNotes As String


    Public Sub New(ByVal LN As String, ByVal FN As String, ByVal EM As String, ByVal Ad As String, ByVal Cty As String, ByVal ST As String, ByVal Zp As String, ByVal HP As String, ByVal WP As String, ByVal CP As String, ByVal Note As String)
        'constructor

        mLName = LN
        mFName = FN
        mEmail = EM
        mAddress = Ad
        mCity = Cty
        mState = ST
        mZip = Zp
        mHomePh = HP
        mWorkPh = WP
        mCellPh = CP
        mNotes = Note

    End Sub 'End Constructor

    Public Property LName() As String
        Get
            Return mLName

        End Get
        Set(ByVal Value As String)
            mLName = Value
        End Set
    End Property
    Public Property FName() As String
        Get
            Return mFName
        End Get
        Set(ByVal Value As String)
            mFName = Value
        End Set
    End Property

    Public Property Email() As String
        Get
            Return mEmail
        End Get
        Set(ByVal Value As String)
            mEmail = Value
        End Set
    End Property

    Public Property Address() As String
        Get
            Return mAddress
        End Get
        Set(ByVal Value As String)
            mAddress = Value
        End Set
    End Property

    Public Property City() As String
        Get
            Return mCity
        End Get
        Set(ByVal Value As String)
            mCity = Value
        End Set
    End Property

    Public Property State() As String
        Get
            Return mState
        End Get
        Set(ByVal Value As String)
            mState = Value
        End Set
    End Property

    Public Property Zip() As String
        Get
            Return mZip
        End Get
        Set(ByVal Value As String)
            mZip = Value
        End Set
    End Property

    Public Property HomePh() As String
        Get
            Return mHomePh
        End Get
        Set(ByVal Value As String)
            mHomePh = Value

        End Set
    End Property

    Public Property WorkPh() As String
        Get
            Return mWorkPh
        End Get
        Set(ByVal Value As String)
            mWorkPh = Value
        End Set
    End Property

    Public Property CellPh() As String
        Get
            Return mCellPh
        End Get
        Set(ByVal Value As String)
            mCellPh = Value
        End Set
    End Property

    Public Property Notes() As String
        Get
            Return mNotes
        End Get
        Set(ByVal Value As String)
            mNotes = Value
        End Set
    End Property
    Public Function CompareTo(ByVal obj As Object) As Integer Implements System.IComparable.CompareTo
        Dim temp As Contact
        temp = CType(obj, Contact)

        Return Me.mLName.CompareTo(temp.mLName)
    End Function
End Class
