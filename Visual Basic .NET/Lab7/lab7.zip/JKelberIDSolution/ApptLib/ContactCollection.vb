Imports System
Imports System.Collections
Imports System.IO
Imports System.Runtime.Serialization.Formatters.Soap
<Serializable()> _
Public Class ContactCollection
    Inherits CollectionBase

    Public Sub Serialize(ByVal CC As ContactCollection, ByVal filename As String)
        Dim fs As FileStream

        fs = New FileStream(filename, FileMode.Create)

        Dim SoapFormatter As New SoapFormatter
        SoapFormatter.Serialize(fs, CC)
        fs.Close()
    End Sub
    Public Shared Function _
                DeSerialize(ByVal filename As String) As ContactCollection
        Dim fs As FileStream
        fs = New FileStream(filename, FileMode.Open)
        Dim SoapFormatter As New SoapFormatter
        Dim CC As ContactCollection
        CC = SoapFormatter.Deserialize(fs)
        fs.Close()
        Return CC

    End Function

    Public Sub New()

        MyBase.New()
    End Sub

    Default Public Property Item(ByVal idx As Integer) As Contact
        Get
            Return CType(List.Item(idx), Contact)
            ' Dim CC As ContactCollection
            'CC.Item(5)

        End Get
        Set(ByVal Value As Contact)
            List(idx) = Value
        End Set
    End Property

    Public Function Add(ByVal aContact As Contact)

        If aContact Is Nothing Then
            Throw New ArgumentNullException
        End If
        If aContact.LName = "" Or aContact.FName = "" Then
            Throw New ArgumentException("Both First Name and Last Name must be filled in!")
        End If

        If (aContact.HomePh = "" Or aContact.WorkPh = "" Or aContact.CellPh = "") And (aContact.Address = "" And aContact.City = "") Then
            Throw New ArgumentException(" Must have either a phone number or an address!")

        End If
        'Tests to see if there is a duplicate date
        If Me.IndexOf(aContact) >= 0 Then

            Throw New ArgumentException("Duplicate Object")

        End If

        If aContact.Email = "" Then
            aContact.Email = "?"
        End If

        If aContact.Address = "" Then
            aContact.Address = "?"
        End If

        If aContact.City = "" Then
            aContact.City = "?"
        End If

        If aContact.State = "" Then
            aContact.State = "?"
        End If

        If aContact.Zip = "" Then
            aContact.Zip = "?"
        End If

        If aContact.HomePh = "" Then
            aContact.HomePh = "?"
        End If

        If aContact.WorkPh = "" Then
            aContact.WorkPh = "?"
        End If

        If aContact.CellPh = "" Then
            aContact.CellPh = "?"
        End If

        If aContact.Notes = "" Then
            aContact.Notes = "(none available)"
        End If

        Return List.Add(aContact)
    End Function

    Public Sub Insert(ByVal idx As Integer, ByVal value As Contact)

        List.Insert(idx, value)
    End Sub

    Public Sub Remove(ByVal aContact As Contact)

        List.Remove(aContact)
    End Sub

    Public Function IndexOf(ByVal con As Contact) As Integer

        Return List.IndexOf(con)
    End Function

    Public Sub Sort()

        ArrayList.Adapter(List).Sort()
    End Sub
End Class
