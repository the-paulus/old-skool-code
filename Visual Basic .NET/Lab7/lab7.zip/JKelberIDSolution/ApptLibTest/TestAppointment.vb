Imports NUnit.Framework
Imports ApptLib


<TestFixture()> _
Public Class TestAppointment

    <Test()> _
    Public Sub constructorandPropertyTest()
        Dim id As Appointment

        id = New Appointment(Today, "Birthday", "Laura", "Backyard", New TimeSpan(1, 0, 0), "Bring Cake")
        Assertion.AssertEquals(Today, id.Start)
        Assertion.AssertEquals("Birthday", id.Reason)
        Assertion.AssertEquals("Backyard", id.Location)
        Assertion.AssertEquals("Laura", id.Contact)
        Assertion.AssertEquals(New TimeSpan(1, 0, 0), id.Duration)
        Assertion.AssertEquals("Bring Cake", id.Notes)

    End Sub
    <Test()> _
  Public Sub propertyTest()
        Dim id As Appointment

        id = New Appointment(Today, "Birthday", "Laura", "Backyard", New TimeSpan(1, 0, 0), "Bring Cake")
        id.Contact = "Laura"
        id.Location = "Backyard"
        id.Duration = New TimeSpan(1, 0, 0)
        id.Notes = "Bring Cake"
        Assertion.AssertEquals("Laura", id.Contact)
        Assertion.AssertEquals("Backyard", id.Location)
        Assertion.AssertEquals("Bring Cake", id.Notes)
        Assertion.AssertEquals(New TimeSpan(1, 0, 0), id.Duration)

    End Sub
    <Test(), ExpectedException(GetType(ArgumentNullException))> _
    Public Sub ExpectAnException()
        Dim id As Appointment

        id = New Appointment(Today, "Birthday", "Laura", "Backyard", New TimeSpan(1, 0, 0), "Bring Cake")

        id.Location = ""

    End Sub
End Class

