Imports NUnit.Framework
Imports ApptLib
<TestFixture()> _
Public Class TestImportantDate

    <Test()> _
    Public Sub constructorandPropertyTest()
        Dim id As ImportantDate

        id = New ImportantDate(Today, "Great Day", False)
        Assertion.AssertEquals(Today, id.Start)
        Assertion.AssertEquals("Great Day", id.Reason)
        Assertion.AssertEquals(False, id.Recurring)

    End Sub
    <Test()> _
  Public Sub propertyTest()
        Dim id As ImportantDate

        id = New ImportantDate(Today, "Great Day", False)
        id.Start = Today.AddDays(1)
        id.Reason = "TGIw"
        id.Recurring = True
        Assertion.AssertEquals(Today.AddDays(1), id.Start)
        Assertion.AssertEquals("TGIw", id.Reason)
        Assertion.AssertEquals(True, id.Recurring)

    End Sub

    <Test(), ExpectedException(GetType(ArgumentOutOfRangeException))> _
       Public Sub ExpectedException1()
        Dim id As ImportantDate
        id = New ImportantDate(#3/30/2004#, "Because", False)

        id.Start = #3/10/2004#

    End Sub
    <Test(), ExpectedException(GetType(ArgumentNullException))> _
    Public Sub ExpectedExcpetion2()
        Dim id As ImportantDate

        id = New ImportantDate(#3/30/2004#, "Because", False)
        id.Reason = ""
    End Sub
    <Test(), ExpectedException(GetType(ArgumentException))> _
    Public Sub ExpectedException3()
        Dim id As ImportantDate

        id = New ImportantDate(#3/30/2004#, "Because", False)

        id.Reason = "none"
    End Sub

End Class

