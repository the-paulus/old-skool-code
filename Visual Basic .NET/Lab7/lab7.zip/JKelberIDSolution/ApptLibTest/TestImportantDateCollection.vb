Imports NUnit.Framework
Imports ApptLib

<TestFixture()> _
Public Class TestImportantDateCollection

    <Test()> _
    Public Sub CollectionConstructorandPropertyTest()
        Dim myCollection As ImportantDateCollection
        Dim Anniversary As ImportantDate
        Dim Wedding As ImportantDate
        Dim StaffMeeting As Appointment

        myCollection = New ImportantDateCollection
        Anniversary = New ImportantDate(Today, "Wedding", True)
        Wedding = New ImportantDate(#4/6/2004#, "Friends Wedding", False)
        StaffMeeting = New Appointment(#7/2/2004#, "Discuss proposals", "Staff", "Office", New TimeSpan(0, 1, 0), "")

        myCollection.Add(Anniversary)
        myCollection.Add(Wedding)
        myCollection.Add(StaffMeeting)

        Assertion.AssertEquals(0, myCollection.IndexOf(Anniversary))
        Assertion.AssertEquals(1, myCollection.IndexOf(Wedding))
        Assertion.AssertEquals(2, myCollection.IndexOf(StaffMeeting))

        myCollection.Remove(StaffMeeting)

        Assertion.AssertEquals(2, myCollection.Count)


    End Sub

    <Test(), ExpectedException(GetType(ArgumentException))> _
    Public Sub ExpectanException1()
        Dim myCollection As ImportantDateCollection
        Dim Wedding As ImportantDate

        myCollection = New ImportantDateCollection
        Wedding = New ImportantDate(#3/30/2004#, "Sister is getting married", False)

        myCollection.Add(Wedding)
        myCollection.Add(Wedding)

    End Sub
    <Test(), ExpectedException(GetType(ArgumentOutOfRangeException))> _
    Public Sub ExpectanException2()
        Dim myCollection As ImportantDateCollection
        Dim StaffMeeting As ImportantDate

        myCollection = New ImportantDateCollection
        StaffMeeting = New ImportantDate(#3/10/2004#, "Staff Meeting", False)

        myCollection.Add(StaffMeeting)

    End Sub

End Class
