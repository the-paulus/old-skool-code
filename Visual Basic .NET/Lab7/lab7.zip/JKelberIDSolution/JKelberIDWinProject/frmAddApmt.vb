Imports ApptLib
Public Class frmAddApmt
    Inherits System.Windows.Forms.Form
    Private mf As frmMain
    Private start As Date
    Private idc As ImportantDateCollection

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub
    Public Sub New(ByVal mf As frmMain, ByVal startdate As Date, ByVal idc As ImportantDateCollection)
        MyBase.New()
        InitializeComponent()
        Me.mf = mf
        start = startdate
        lblStart.Text = start
        Me.idc = idc
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblStart As System.Windows.Forms.Label
    Friend WithEvents txtReason As System.Windows.Forms.TextBox
    Friend WithEvents txtContact As System.Windows.Forms.TextBox
    Friend WithEvents txtLocation As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txthrs As System.Windows.Forms.TextBox
    Friend WithEvents txtmins As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents txtNotes As System.Windows.Forms.TextBox
    Friend WithEvents lblException As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lblStart = New System.Windows.Forms.Label
        Me.txtReason = New System.Windows.Forms.TextBox
        Me.txtNotes = New System.Windows.Forms.TextBox
        Me.txtContact = New System.Windows.Forms.TextBox
        Me.txtLocation = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.txthrs = New System.Windows.Forms.TextBox
        Me.txtmins = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.btnOk = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.lblException = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'lblStart
        '
        Me.lblStart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStart.Location = New System.Drawing.Point(120, 32)
        Me.lblStart.Name = "lblStart"
        Me.lblStart.Size = New System.Drawing.Size(144, 23)
        Me.lblStart.TabIndex = 0
        '
        'txtReason
        '
        Me.txtReason.Location = New System.Drawing.Point(120, 80)
        Me.txtReason.Name = "txtReason"
        Me.txtReason.Size = New System.Drawing.Size(256, 20)
        Me.txtReason.TabIndex = 1
        Me.txtReason.Text = ""
        '
        'txtNotes
        '
        Me.txtNotes.Location = New System.Drawing.Point(120, 264)
        Me.txtNotes.Multiline = True
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.Size = New System.Drawing.Size(184, 80)
        Me.txtNotes.TabIndex = 2
        Me.txtNotes.Text = ""
        '
        'txtContact
        '
        Me.txtContact.Location = New System.Drawing.Point(120, 128)
        Me.txtContact.Name = "txtContact"
        Me.txtContact.Size = New System.Drawing.Size(256, 20)
        Me.txtContact.TabIndex = 3
        Me.txtContact.Text = ""
        '
        'txtLocation
        '
        Me.txtLocation.Location = New System.Drawing.Point(120, 168)
        Me.txtLocation.Name = "txtLocation"
        Me.txtLocation.Size = New System.Drawing.Size(256, 20)
        Me.txtLocation.TabIndex = 5
        Me.txtLocation.Text = ""
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Start"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Reason"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 128)
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Contact"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 168)
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Location"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(8, 288)
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Notes"
        '
        'txthrs
        '
        Me.txthrs.Location = New System.Drawing.Point(136, 216)
        Me.txthrs.Name = "txthrs"
        Me.txthrs.Size = New System.Drawing.Size(24, 20)
        Me.txthrs.TabIndex = 12
        Me.txthrs.Text = ""
        '
        'txtmins
        '
        Me.txtmins.Location = New System.Drawing.Point(256, 216)
        Me.txtmins.Name = "txtmins"
        Me.txtmins.Size = New System.Drawing.Size(24, 20)
        Me.txtmins.TabIndex = 13
        Me.txtmins.Text = ""
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(8, 216)
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Duration"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(176, 216)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 23)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Hours"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(304, 216)
        Me.Label8.Name = "Label8"
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Minutes"
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(344, 280)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.TabIndex = 17
        Me.btnOk.Text = "Ok"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(344, 312)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.TabIndex = 18
        Me.btnCancel.Text = "Cancel"
        '
        'lblException
        '
        Me.lblException.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblException.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblException.Location = New System.Drawing.Point(16, 352)
        Me.lblException.Name = "lblException"
        Me.lblException.Size = New System.Drawing.Size(400, 23)
        Me.lblException.TabIndex = 19
        Me.lblException.Visible = False
        '
        'frmAddApmt
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 13)
        Me.ClientSize = New System.Drawing.Size(432, 382)
        Me.Controls.Add(Me.lblException)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtmins)
        Me.Controls.Add(Me.txthrs)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtLocation)
        Me.Controls.Add(Me.txtContact)
        Me.Controls.Add(Me.txtNotes)
        Me.Controls.Add(Me.txtReason)
        Me.Controls.Add(Me.lblStart)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmAddApmt"
        Me.Text = "Add New Appointment"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        Dim hrs As Integer
        Dim mins As Integer

        hrs = Convert.ToInt16(txthrs.Text)
        mins = Convert.ToInt16(txtmins.Text)

        Dim Apmt As Appointment
        Apmt = New Appointment(start, txtReason.Text, txtContact.Text, txtLocation.Text, New TimeSpan(hrs, mins, 0), txtNotes.Text)

        Try
            idc.Add(Apmt)
            Me.Dispose()
            mf.Show()
        Catch ex As ArgumentException
            lblException.Text = ex.Message
            lblException.Visible = True
        End Try

    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Dispose()
        mf.Show()
    End Sub
End Class
