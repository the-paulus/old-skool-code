Imports ApptLib

Public Class frmChgApmt
    Inherits System.Windows.Forms.Form
    Private mf As frmMain
    Private ap As Appointment
    Private idc As ImportantDateCollection

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub
    Public Sub New(ByVal mf As frmMain, ByVal ap As Appointment, ByVal idc As ImportantDateCollection)
        MyBase.New()
        Me.mf = mf
        Me.ap = ap
        Me.idc = idc

        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblException As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtmins As System.Windows.Forms.TextBox
    Friend WithEvents txthrs As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtLocation As System.Windows.Forms.TextBox
    Friend WithEvents txtContact As System.Windows.Forms.TextBox
    Friend WithEvents txtNotes As System.Windows.Forms.TextBox
    Friend WithEvents txtReason As System.Windows.Forms.TextBox
    Friend WithEvents txtStart As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lblException = New System.Windows.Forms.Label
        Me.btnCancel = New System.Windows.Forms.Button
        Me.btnOk = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtmins = New System.Windows.Forms.TextBox
        Me.txthrs = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtLocation = New System.Windows.Forms.TextBox
        Me.txtContact = New System.Windows.Forms.TextBox
        Me.txtNotes = New System.Windows.Forms.TextBox
        Me.txtReason = New System.Windows.Forms.TextBox
        Me.txtStart = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'lblException
        '
        Me.lblException.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblException.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblException.Location = New System.Drawing.Point(32, 312)
        Me.lblException.Name = "lblException"
        Me.lblException.Size = New System.Drawing.Size(400, 23)
        Me.lblException.TabIndex = 37
        Me.lblException.Visible = False
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(360, 272)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.TabIndex = 36
        Me.btnCancel.Text = "Cancel"
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(360, 240)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.TabIndex = 35
        Me.btnOk.Text = "Ok"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(304, 176)
        Me.Label8.Name = "Label8"
        Me.Label8.TabIndex = 34
        Me.Label8.Text = "Minutes"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(176, 176)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 23)
        Me.Label7.TabIndex = 33
        Me.Label7.Text = "Hours"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(32, 176)
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 32
        Me.Label6.Text = "Duration"
        '
        'txtmins
        '
        Me.txtmins.Location = New System.Drawing.Point(256, 176)
        Me.txtmins.Name = "txtmins"
        Me.txtmins.Size = New System.Drawing.Size(24, 20)
        Me.txtmins.TabIndex = 31
        Me.txtmins.Text = ""
        '
        'txthrs
        '
        Me.txthrs.Location = New System.Drawing.Point(136, 176)
        Me.txthrs.Name = "txthrs"
        Me.txthrs.Size = New System.Drawing.Size(24, 20)
        Me.txthrs.TabIndex = 30
        Me.txthrs.Text = ""
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(32, 248)
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 29
        Me.Label5.Text = "Notes"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(32, 136)
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Location"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(32, 96)
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 27
        Me.Label3.Text = "Contact"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(32, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "Reason"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(32, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "Start"
        '
        'txtLocation
        '
        Me.txtLocation.Location = New System.Drawing.Point(136, 136)
        Me.txtLocation.Name = "txtLocation"
        Me.txtLocation.Size = New System.Drawing.Size(256, 20)
        Me.txtLocation.TabIndex = 24
        Me.txtLocation.Text = ""
        '
        'txtContact
        '
        Me.txtContact.Location = New System.Drawing.Point(136, 96)
        Me.txtContact.Name = "txtContact"
        Me.txtContact.Size = New System.Drawing.Size(256, 20)
        Me.txtContact.TabIndex = 23
        Me.txtContact.Text = ""
        '
        'txtNotes
        '
        Me.txtNotes.Location = New System.Drawing.Point(136, 224)
        Me.txtNotes.Multiline = True
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.Size = New System.Drawing.Size(184, 80)
        Me.txtNotes.TabIndex = 22
        Me.txtNotes.Text = ""
        '
        'txtReason
        '
        Me.txtReason.Location = New System.Drawing.Point(136, 56)
        Me.txtReason.Name = "txtReason"
        Me.txtReason.Size = New System.Drawing.Size(256, 20)
        Me.txtReason.TabIndex = 21
        Me.txtReason.Text = ""
        '
        'txtStart
        '
        Me.txtStart.Location = New System.Drawing.Point(136, 16)
        Me.txtStart.Name = "txtStart"
        Me.txtStart.Size = New System.Drawing.Size(256, 20)
        Me.txtStart.TabIndex = 38
        Me.txtStart.Text = ""
        '
        'frmChgApmt
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 342)
        Me.Controls.Add(Me.txtStart)
        Me.Controls.Add(Me.lblException)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtmins)
        Me.Controls.Add(Me.txthrs)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtLocation)
        Me.Controls.Add(Me.txtContact)
        Me.Controls.Add(Me.txtNotes)
        Me.Controls.Add(Me.txtReason)
        Me.Name = "frmChgApmt"
        Me.Text = "Edit Appointment"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Dispose()
        mf.Show()
    End Sub



    Private Sub btnOk_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOk.Click
        ap.Start = txtStart.Text
        ap.Reason = txtReason.Text
        ap.Contact = txtContact.Text
        ap.Location = txtLocation.Text
        ap.Notes = txtNotes.Text
        Dim hrs As Int16
        Dim min As Int16
        hrs = Convert.ToInt16(txthrs.Text)
        min = Convert.ToInt16(txtmins.Text)
        ap.Duration = New TimeSpan(hrs, min, 0)

        Me.Dispose()
        mf.Show()

    End Sub

    Private Sub frmChgApmt_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtStart.Text = ap.Start
        txtReason.Text = ap.Reason
        txtContact.Text = ap.Contact
        txtLocation.Text = ap.Location
        txtNotes.Text = ap.Notes
        txthrs.Text = ap.Duration.Hours
        txtmins.Text = ap.Duration.Minutes

    End Sub
End Class
