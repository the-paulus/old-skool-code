Imports System
Imports ApptLib

Public Class frmContacts
    Inherits System.Windows.Forms.Form

    Private mf As frmMain
    Private CC As ContactCollection
    Private CurrentContact As Contact


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub
    Public Sub New(ByVal main As frmMain, ByVal CCol As ContactCollection)
        MyBase.New()
        InitializeComponent()
        Me.mf = main
        Me.CC = CCol

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtLName As System.Windows.Forms.TextBox
    Friend WithEvents txtFName As System.Windows.Forms.TextBox
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtState As System.Windows.Forms.TextBox
    Friend WithEvents txtCity As System.Windows.Forms.TextBox
    Friend WithEvents txtZip As System.Windows.Forms.TextBox
    Friend WithEvents txtHPhone As System.Windows.Forms.TextBox
    Friend WithEvents txtWPhone As System.Windows.Forms.TextBox
    Friend WithEvents txtCPhone As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtNotes As System.Windows.Forms.TextBox
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnFirst As System.Windows.Forms.Button
    Friend WithEvents btnPrev As System.Windows.Forms.Button
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnLast As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents lblerror As System.Windows.Forms.Label
    Friend WithEvents btnReset As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtLName = New System.Windows.Forms.TextBox
        Me.txtFName = New System.Windows.Forms.TextBox
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.txtAddress = New System.Windows.Forms.TextBox
        Me.txtState = New System.Windows.Forms.TextBox
        Me.txtCity = New System.Windows.Forms.TextBox
        Me.txtZip = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.txtHPhone = New System.Windows.Forms.TextBox
        Me.txtWPhone = New System.Windows.Forms.TextBox
        Me.txtCPhone = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtNotes = New System.Windows.Forms.TextBox
        Me.btnAdd = New System.Windows.Forms.Button
        Me.btnUpdate = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.btnFirst = New System.Windows.Forms.Button
        Me.btnPrev = New System.Windows.Forms.Button
        Me.btnNext = New System.Windows.Forms.Button
        Me.btnLast = New System.Windows.Forms.Button
        Me.btnDelete = New System.Windows.Forms.Button
        Me.lblerror = New System.Windows.Forms.Label
        Me.btnReset = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(24, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Last Name"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(24, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "First Name"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(24, 96)
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Email"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(24, 136)
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Address"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(24, 256)
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Zip"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(24, 216)
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "State"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(24, 176)
        Me.Label7.Name = "Label7"
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "City"
        '
        'txtLName
        '
        Me.txtLName.Location = New System.Drawing.Point(88, 16)
        Me.txtLName.Name = "txtLName"
        Me.txtLName.Size = New System.Drawing.Size(184, 20)
        Me.txtLName.TabIndex = 7
        Me.txtLName.Text = ""
        '
        'txtFName
        '
        Me.txtFName.Location = New System.Drawing.Point(88, 56)
        Me.txtFName.Name = "txtFName"
        Me.txtFName.Size = New System.Drawing.Size(184, 20)
        Me.txtFName.TabIndex = 8
        Me.txtFName.Text = ""
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(88, 96)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(184, 20)
        Me.txtEmail.TabIndex = 9
        Me.txtEmail.Text = ""
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(88, 136)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(184, 20)
        Me.txtAddress.TabIndex = 10
        Me.txtAddress.Text = ""
        '
        'txtState
        '
        Me.txtState.Location = New System.Drawing.Point(88, 216)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(32, 20)
        Me.txtState.TabIndex = 12
        Me.txtState.Text = ""
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(88, 176)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(184, 20)
        Me.txtCity.TabIndex = 11
        Me.txtCity.Text = ""
        '
        'txtZip
        '
        Me.txtZip.Location = New System.Drawing.Point(88, 256)
        Me.txtZip.Name = "txtZip"
        Me.txtZip.Size = New System.Drawing.Size(40, 20)
        Me.txtZip.TabIndex = 13
        Me.txtZip.Text = ""
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(312, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "H-Phone"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(312, 56)
        Me.Label9.Name = "Label9"
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "W-Phone"
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(312, 96)
        Me.Label10.Name = "Label10"
        Me.Label10.TabIndex = 16
        Me.Label10.Text = "C-Phone"
        '
        'txtHPhone
        '
        Me.txtHPhone.Location = New System.Drawing.Point(416, 16)
        Me.txtHPhone.Name = "txtHPhone"
        Me.txtHPhone.TabIndex = 17
        Me.txtHPhone.Text = ""
        '
        'txtWPhone
        '
        Me.txtWPhone.Location = New System.Drawing.Point(416, 56)
        Me.txtWPhone.Name = "txtWPhone"
        Me.txtWPhone.TabIndex = 18
        Me.txtWPhone.Text = ""
        '
        'txtCPhone
        '
        Me.txtCPhone.Location = New System.Drawing.Point(416, 96)
        Me.txtCPhone.Name = "txtCPhone"
        Me.txtCPhone.TabIndex = 19
        Me.txtCPhone.Text = ""
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(312, 136)
        Me.Label11.Name = "Label11"
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "Notes"
        '
        'txtNotes
        '
        Me.txtNotes.Location = New System.Drawing.Point(312, 168)
        Me.txtNotes.Multiline = True
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.Size = New System.Drawing.Size(312, 112)
        Me.txtNotes.TabIndex = 21
        Me.txtNotes.Text = ""
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(568, 8)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(104, 23)
        Me.btnAdd.TabIndex = 22
        Me.btnAdd.Text = "Add New Contact"
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(568, 48)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(104, 23)
        Me.btnUpdate.TabIndex = 23
        Me.btnUpdate.Text = "Update"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(568, 88)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(104, 24)
        Me.btnCancel.TabIndex = 24
        Me.btnCancel.Text = "Cancel"
        '
        'btnFirst
        '
        Me.btnFirst.Location = New System.Drawing.Point(312, 288)
        Me.btnFirst.Name = "btnFirst"
        Me.btnFirst.Size = New System.Drawing.Size(40, 23)
        Me.btnFirst.TabIndex = 25
        Me.btnFirst.Text = "First"
        '
        'btnPrev
        '
        Me.btnPrev.Location = New System.Drawing.Point(368, 288)
        Me.btnPrev.Name = "btnPrev"
        Me.btnPrev.Size = New System.Drawing.Size(40, 23)
        Me.btnPrev.TabIndex = 26
        Me.btnPrev.Text = "Prev."
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(424, 288)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(40, 23)
        Me.btnNext.TabIndex = 27
        Me.btnNext.Text = "Next"
        '
        'btnLast
        '
        Me.btnLast.Location = New System.Drawing.Point(480, 288)
        Me.btnLast.Name = "btnLast"
        Me.btnLast.Size = New System.Drawing.Size(40, 23)
        Me.btnLast.TabIndex = 28
        Me.btnLast.Text = "Last"
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(608, 288)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.TabIndex = 29
        Me.btnDelete.Text = "Delete"
        '
        'lblerror
        '
        Me.lblerror.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblerror.Location = New System.Drawing.Point(8, 288)
        Me.lblerror.Name = "lblerror"
        Me.lblerror.Size = New System.Drawing.Size(288, 23)
        Me.lblerror.TabIndex = 30
        Me.lblerror.Visible = False
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(568, 128)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(104, 23)
        Me.btnReset.TabIndex = 31
        Me.btnReset.Text = "Reset Fields"
        '
        'frmContacts
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(696, 318)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.lblerror)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnLast)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btnPrev)
        Me.Controls.Add(Me.btnFirst)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.txtNotes)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtCPhone)
        Me.Controls.Add(Me.txtWPhone)
        Me.Controls.Add(Me.txtHPhone)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtZip)
        Me.Controls.Add(Me.txtState)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.txtFName)
        Me.Controls.Add(Me.txtLName)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmContacts"
        Me.Text = "Contact List"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        lblerror.Visible = False
        Dim newContact As Contact
        newContact = New Contact(txtLName.Text, txtFName.Text, txtEmail.Text, txtAddress.Text, txtCity.Text, txtState.Text, txtZip.Text, txtHPhone.Text, txtWPhone.Text, txtCPhone.Text, txtNotes.Text)
        Try
            CC.Add(newContact)
            CurrentContact = newContact
            CC.Sort()
        Catch ex As Exception
            lblerror.Text = ex.Message
            lblerror.Visible = True

        End Try
    End Sub

    Private Sub btnFirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFirst.Click
        Dim firstContact As Contact
        firstContact = CC.Item(0)
        ContactFill(firstContact)

    End Sub

    Private Sub btnLast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLast.Click
        Dim LastContact As Contact
        LastContact = CC.Item(CC.Count - 1)
        ContactFill(LastContact)
    End Sub

    Private Sub btnPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrev.Click

        If CC.IndexOf(CurrentContact) = 0 Then
            txtFName.Focus()
        Else
            Dim PrevContact As Contact
            PrevContact = CC.Item(CC.IndexOf(CurrentContact) - 1)
            ContactFill(PrevContact)

        End If

    End Sub

    Public Sub ContactFill(ByVal theContact As Contact)
        txtAddress.Text = theContact.Address
        txtCity.Text = theContact.City
        txtCPhone.Text = theContact.CellPh
        txtEmail.Text = theContact.Email
        txtFName.Text = theContact.FName
        txtHPhone.Text = theContact.HomePh
        txtLName.Text = theContact.LName
        txtNotes.Text = theContact.Notes
        txtState.Text = theContact.State
        txtWPhone.Text = theContact.WorkPh
        txtZip.Text = theContact.Zip

        CurrentContact = theContact
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Dispose()
        mf.Show()
    End Sub

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        If CC.IndexOf(CurrentContact) = (CC.Count - 1) Then
            txtFName.Focus()

        Else
            Dim nextContact As Contact
            nextContact = CC.Item(CC.IndexOf(CurrentContact) + 1)
            ContactFill(nextContact)

        End If
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Dim theContact As Contact
        theContact = New Contact("", "", "", "", "", "", "", "", "", "", "")
        theContact.Address = txtAddress.Text
        theContact.City = txtCity.Text
        theContact.CellPh = txtCPhone.Text
        theContact.Email = txtEmail.Text
        theContact.FName = txtFName.Text
        theContact.HomePh = txtHPhone.Text
        theContact.LName = txtLName.Text
        theContact.Notes = txtNotes.Text
        theContact.State = txtState.Text
        theContact.WorkPh = txtWPhone.Text
        theContact.Zip = txtZip.Text

        CC.Item(CC.IndexOf(CurrentContact)) = theContact
        CurrentContact = theContact
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Dim NewIndex As Integer
        NewIndex = CC.IndexOf(CurrentContact)
        CC.Remove(CurrentContact)

        If CC.Count > NewIndex Then
            ContactFill(CC.Item(NewIndex))
        Else
            NewIndex -= 1
            ContactFill(CC.Item(NewIndex))
        End If
        txtLName.Focus()

    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        txtAddress.Text = ""
        txtCity.Text = ""
        txtCPhone.Text = ""
        txtEmail.Text = ""
        txtFName.Text = ""
        txtHPhone.Text = ""
        txtLName.Text = ""
        txtNotes.Text = ""
        txtState.Text = ""
        txtWPhone.Text = ""
        txtZip.Text = ""

        txtLName.Focus()

    End Sub
End Class
