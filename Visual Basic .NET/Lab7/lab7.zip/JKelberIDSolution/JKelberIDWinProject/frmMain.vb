Imports ApptLib
Public Class frmMain
    Inherits System.Windows.Forms.Form
    Private idc As ImportantDateCollection
    Private CC As ContactCollection
    Private dts As ImportantDateCollection
    Private selectedDate As Date

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnAddDate As System.Windows.Forms.Button
    Friend WithEvents btnAddApmt As System.Windows.Forms.Button
    Friend WithEvents btnContacts As System.Windows.Forms.Button
    Friend WithEvents MonthCalendar As System.Windows.Forms.MonthCalendar
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnSave = New System.Windows.Forms.Button
        Me.btnAddDate = New System.Windows.Forms.Button
        Me.btnAddApmt = New System.Windows.Forms.Button
        Me.btnContacts = New System.Windows.Forms.Button
        Me.MonthCalendar = New System.Windows.Forms.MonthCalendar
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.SuspendLayout()
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(232, 8)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(128, 23)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Save"
        '
        'btnAddDate
        '
        Me.btnAddDate.Location = New System.Drawing.Point(232, 48)
        Me.btnAddDate.Name = "btnAddDate"
        Me.btnAddDate.Size = New System.Drawing.Size(128, 23)
        Me.btnAddDate.TabIndex = 1
        Me.btnAddDate.Text = "Add a Significant Date"
        '
        'btnAddApmt
        '
        Me.btnAddApmt.Location = New System.Drawing.Point(232, 88)
        Me.btnAddApmt.Name = "btnAddApmt"
        Me.btnAddApmt.Size = New System.Drawing.Size(128, 23)
        Me.btnAddApmt.TabIndex = 2
        Me.btnAddApmt.Text = "Add Appointment"
        '
        'btnContacts
        '
        Me.btnContacts.Location = New System.Drawing.Point(232, 128)
        Me.btnContacts.Name = "btnContacts"
        Me.btnContacts.Size = New System.Drawing.Size(128, 23)
        Me.btnContacts.TabIndex = 3
        Me.btnContacts.Text = "Contact List"
        '
        'MonthCalendar
        '
        Me.MonthCalendar.Location = New System.Drawing.Point(8, 8)
        Me.MonthCalendar.Name = "MonthCalendar"
        Me.MonthCalendar.TabIndex = 5
        '
        'ListBox1
        '
        Me.ListBox1.Location = New System.Drawing.Point(8, 176)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(360, 238)
        Me.ListBox1.TabIndex = 6
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(384, 430)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.MonthCalendar)
        Me.Controls.Add(Me.btnContacts)
        Me.Controls.Add(Me.btnAddApmt)
        Me.Controls.Add(Me.btnAddDate)
        Me.Controls.Add(Me.btnSave)
        Me.Name = "frmMain"
        Me.Text = "Dates and Appointments"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        idc.Serialize(idc, ".\importantdates.soap")
        CC.Serialize(CC, ".\contacts.soap")
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            idc = _
            ImportantDateCollection.DeSerialize(".\importantdates.soap")
            Me.fillListBox(Today)
        Catch ex As Exception
            idc = New ImportantDateCollection
        End Try

        Try
            CC = _
            ContactCollection.DeSerialize(".\contacts.soap")
        Catch ex As Exception
            CC = New ContactCollection
        End Try
        selectedDate = Today
    End Sub

    Private Sub btnAddDate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddDate.Click
        Dim addDtForm As frmAddDate
        addDtForm = New frmAddDate(Me, MonthCalendar.SelectionStart, idc)
        addDtForm.Show()
    End Sub


    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Dim i As Integer
        i = ListBox1.SelectedIndex
        'dts(i) important date i want to change
        If dts(i).GetType.ToString = "ApptLib.Appointment" Then
            Dim chgApmtForm As frmChgApmt
            chgApmtForm = New frmChgApmt(Me, dts(i), idc)
            chgApmtForm.Show()
        Else
            Dim chgDTForm As frmChgDate
            chgDTForm = New frmChgDate(Me, dts(i), idc)
            chgDTForm.Show()
        End If

    End Sub

    Private Sub fillListBox(ByVal dt As Date)
        Dim lstItem As String

        dts = idc.GetDatesBetween(dt, dt.AddDays(7))
        ListBox1.Items.Clear()
        For Each id As ImportantDate In dts
            lstItem = ""
            lstItem &= id.Start.ToShortDateString & " "
            lstItem &= id.Reason
            ListBox1.Items.Add(lstItem)
        Next

    End Sub


    Private Sub MonthCalendar_DateChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles MonthCalendar.DateChanged
        Me.ListBox1.Items.Clear()
        Me.fillListBox(e.Start)
        selectedDate = e.Start
    End Sub

    Private Sub frmMain_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        Me.fillListBox(selectedDate)
    End Sub

    Private Sub btnAddApmt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddApmt.Click
        Dim addApmtForm As frmAddApmt
        addApmtForm = New frmAddApmt(Me, MonthCalendar.SelectionStart, idc)
        addApmtForm.Show()

    End Sub

    Private Sub btnContacts_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnContacts.Click
        Dim addContactForm As frmContacts
        addContactForm = New frmContacts(Me, CC)
        addContactForm.Show()

    End Sub
End Class
