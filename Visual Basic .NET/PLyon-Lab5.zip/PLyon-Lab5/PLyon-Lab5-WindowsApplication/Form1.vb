Imports plyon_applib
Imports System.Windows.Forms.ListBox.ObjectCollection

Public Class Form1
    Inherits System.Windows.Forms.Form
    Dim dates_appointments As System.Windows.Forms.ListBox.ObjectCollection

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MonthCalendar1 As System.Windows.Forms.MonthCalendar
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnContacts As System.Windows.Forms.Button
    Friend WithEvents cbbApptOnly As System.Windows.Forms.CheckBox
    Friend WithEvents btnAddSDate As System.Windows.Forms.Button
    Friend WithEvents btnAddAppointment As System.Windows.Forms.Button
    Friend WithEvents lsbApptList As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MonthCalendar1 = New System.Windows.Forms.MonthCalendar
        Me.btnSave = New System.Windows.Forms.Button
        Me.btnContacts = New System.Windows.Forms.Button
        Me.cbbApptOnly = New System.Windows.Forms.CheckBox
        Me.btnAddSDate = New System.Windows.Forms.Button
        Me.btnAddAppointment = New System.Windows.Forms.Button
        Me.lsbApptList = New System.Windows.Forms.ListBox
        Me.SuspendLayout()
        '
        'MonthCalendar1
        '
        Me.MonthCalendar1.Location = New System.Drawing.Point(8, 8)
        Me.MonthCalendar1.Name = "MonthCalendar1"
        Me.MonthCalendar1.TabIndex = 0
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(216, 16)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.TabIndex = 1
        Me.btnSave.Text = "&Save"
        '
        'btnContacts
        '
        Me.btnContacts.Location = New System.Drawing.Point(216, 80)
        Me.btnContacts.Name = "btnContacts"
        Me.btnContacts.TabIndex = 2
        Me.btnContacts.Text = "&Contacts"
        '
        'cbbApptOnly
        '
        Me.cbbApptOnly.Location = New System.Drawing.Point(216, 136)
        Me.cbbApptOnly.Name = "cbbApptOnly"
        Me.cbbApptOnly.Size = New System.Drawing.Size(80, 16)
        Me.cbbApptOnly.TabIndex = 3
        Me.cbbApptOnly.Text = "&Appt Only"
        '
        'btnAddSDate
        '
        Me.btnAddSDate.Location = New System.Drawing.Point(16, 176)
        Me.btnAddSDate.Name = "btnAddSDate"
        Me.btnAddSDate.Size = New System.Drawing.Size(120, 23)
        Me.btnAddSDate.TabIndex = 4
        Me.btnAddSDate.Text = "Add &Significant Date"
        '
        'btnAddAppointment
        '
        Me.btnAddAppointment.Location = New System.Drawing.Point(152, 176)
        Me.btnAddAppointment.Name = "btnAddAppointment"
        Me.btnAddAppointment.Size = New System.Drawing.Size(120, 23)
        Me.btnAddAppointment.TabIndex = 5
        Me.btnAddAppointment.Text = "A&dd Appointment"
        '
        'lsbApptList
        '
        Me.lsbApptList.Location = New System.Drawing.Point(8, 208)
        Me.lsbApptList.Name = "lsbApptList"
        Me.lsbApptList.Size = New System.Drawing.Size(288, 160)
        Me.lsbApptList.TabIndex = 6
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(304, 373)
        Me.Controls.Add(Me.lsbApptList)
        Me.Controls.Add(Me.btnAddAppointment)
        Me.Controls.Add(Me.btnAddSDate)
        Me.Controls.Add(Me.cbbApptOnly)
        Me.Controls.Add(Me.btnContacts)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.MonthCalendar1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnAddSDate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddSDate.Click
        Dim sd As New SDate
        sd.setForm(Me)
        sd.Show()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnAddAppointment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddAppointment.Click
        Dim aa As New AddAppointmentForm
        aa.setForm(Me)
        aa.Show()
    End Sub

    Private Sub MonthCalendar1_DateChanged(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles MonthCalendar1.DateChanged
        Dim i As Integer
        Dim id As ImportantDate

        lsbApptList.Items.Clear()
        For i = 0 To dates_appointments.Count
            id = dates_appointments.Item(i)
            If id.Start = MonthCalendar1.TodayDate Then
                lsbApptList.Items.Add(id.Reason)
            End If
        Next
        'lsbApptList.Items.AddRange(dates_appointments)
        'For i = 0 To dates_appoint
    End Sub

    Public Sub addNewDate(ByVal impdate As ImportantDate)
        dates_appointments.Add(impdate)
    End Sub
End Class
