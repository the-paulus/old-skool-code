Public Class Appointment
    Dim appointment As Date
    Dim start_hour As Integer
    Dim end_hour As Integer
    Dim start_minute As Integer
    Dim end_minute As Integer
    Dim timeofday As String
    Dim note As String

    Public Sub New(ByVal arrangeddate As Date, ByVal shour As Integer, ByVal sminute As Integer, ByVal ehour As Integer, ByVal eminute As Integer, ByVal memo As String)
        appointment = arrangeddate
        start_hour = shour
        start_minute = sminute
        end_hour = ehour
        end_minute = eminute
    End Sub

    Public Property appointmentDate() As Date
        Get
            Return appointment
        End Get
        Set(ByVal Value As Date)
            appointment = Value
        End Set
    End Property

    Public Property startHour() As Integer
        Get
            Return start_hour
        End Get
        Set(ByVal Value As Integer)
            start_hour = Value
        End Set
    End Property

    Public Property startMinute() As Integer
        Get
            Return start_minute
        End Get
        Set(ByVal Value As Integer)
            start_minute = Value
        End Set
    End Property

    Public Property endHour() As Integer
        Get
            Return end_hour
        End Get
        Set(ByVal Value As Integer)
            end_hour = Value
        End Set
    End Property

    Public Property endMinute() As Integer
        Get
            Return end_minute
        End Get
        Set(ByVal Value As Integer)
            end_minute = Value
        End Set
    End Property

    Public Property morningAfternoon() As String
        Get
            Return timeofday
        End Get
        Set(ByVal Value As String)
            timeofday = Value
        End Set
    End Property

    Public Property appointmenNote() As String
        Get
            Return note
        End Get
        Set(ByVal Value As String)
            note = Value
        End Set
    End Property
End Class
