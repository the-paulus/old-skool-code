Public Class ImportantDate
    Private start_date As Date
    Private appt_reason As String
    Private repeate As Boolean
    Private app As Boolean

    Public Sub New(ByVal start As Date, ByVal reason As String, ByVal recur As Boolean)
        start_date = start
        appt_reason = reason
        repeate = recur
    End Sub

    Public Property Start() As Date
        Get
            Return start_date
        End Get
        Set(ByVal Value As Date)
            start_date = Value
        End Set
    End Property

    Public Property Reason() As String
        Get
            Return appt_reason
        End Get
        Set(ByVal Value As String)
            appt_reason = Value
        End Set
    End Property

    Public Property Recurring() As Boolean
        Get
            Return repeate
        End Get
        Set(ByVal Value As Boolean)
            repeate = Value
        End Set
    End Property

    Public Property Appointment() As Boolean
        Get
            Return app
        End Get
        Set(ByVal Value As Boolean)
            app = Value
        End Set
    End Property
End Class
